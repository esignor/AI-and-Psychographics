This archive contains two lexica, one for age and one for gender.

To learn how to use this lexicon, please refer to the paper
Sap, M., Park, G., Eichstaedt, J. E., Kern, M. L., Stillwell, D. J.,
Kosinski, M., Ungar, L. H., & Schwartz, H. A. (2014).
Developing Age and Gender Predictive Lexica over Social Media. In EMNLP

Note that the intercept (marked as "_intercept" in the lexica csvs)
is to be added post weighted lexicon extraction.

See wwbp.org/data.html for a walk through example on how to use the 
lexica.
